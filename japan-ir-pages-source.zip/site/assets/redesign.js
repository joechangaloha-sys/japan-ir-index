/* Navy edition: phone menu, company-list sort and filter, print buttons. Local only. */
(() => {
  const toggle = document.querySelector('.nav-toggle');
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    document.getElementById('site-nav')?.classList.toggle('open', !open);
  });

  document.querySelectorAll('[data-rd-print]').forEach(b => b.addEventListener('click', () => window.print()));

  const table = document.querySelector('[data-co-table]');
  if (!table) return;
  const controls = document.querySelector('[data-co-controls]');
  const search = document.querySelector('[data-co-search]');
  const sort = document.querySelector('[data-co-sort]');
  const filter = document.querySelector('[data-co-filter]');
  const sector = document.querySelector('[data-co-sector]');
  const size = document.querySelector('[data-co-size]');
  const range = document.querySelector('[data-co-range]');
  const count = document.querySelector('[data-co-count]');
  const empty = document.querySelector('[data-co-empty]');
  const az = document.querySelector('[data-co-az]');
  const body = table.tBodies[0];
  const rows = [...body.rows];
  const ja = document.documentElement.lang === 'ja';
  controls.hidden = false;   // without JavaScript the full static table stays readable

  const order = {
    'name': (a, b) => a.dataset.i - b.dataset.i,
    'score-desc': (a, b) => b.dataset.score - a.dataset.score || a.dataset.i - b.dataset.i,
    'score-asc': (a, b) => a.dataset.score - b.dataset.score || a.dataset.i - b.dataset.i,
    'date': (a, b) => b.dataset.date.localeCompare(a.dataset.date) || a.dataset.i - b.dataset.i,
  };
  const keep = {
    'all': () => true,
    'full': r => r.dataset.full === 'true',
    'provisional': r => r.dataset.full === 'false',
    'example': r => r.dataset.example === 'true',
  };
  const update = () => {
    const q = search.value.trim().toLocaleLowerCase();
    let shown = 0;
    rows.sort(order[sort.value]).forEach(r => {
      const match = r.dataset.search.includes(q) && keep[filter.value](r)
        && (!sector || sector.value === 'all' || r.dataset.sector === sector.value)
        && (!size || size.value === 'all' || r.dataset.band === size.value)
        && (!range || range.value === 'all' || (() => { const [lo, hi] = range.value.split('-').map(Number), s = Number(r.dataset.score); return s >= lo && s < hi; })());
      r.hidden = !match;
      if (match) shown++;
      body.appendChild(r);
    });
    if (az) {
      az.hidden = sort.value !== 'name';
      az.querySelectorAll('a').forEach(a => {
        rows.forEach(r => { if (r.id === `co-letter-${a.dataset.letter}`) r.removeAttribute('id'); });
        const first = rows.find(r => !r.hidden && r.dataset.letter === a.dataset.letter);
        a.hidden = !first;
        if (first) first.id = `co-letter-${a.dataset.letter}`;
      });
    }
    count.textContent = ja ? `${shown}社を表示` : `${shown} companies shown`;
    empty.hidden = shown !== 0;
  };
  [search, sort, filter, sector, size, range].filter(Boolean).forEach(el => el.addEventListener(el === search ? 'input' : 'change', update));
  update();
})();
/* Print: open the company page's closed section folds and timelines so the PDF carries all three sections, then restore them. */
(() => {
  let opened = [];
  addEventListener('beforeprint', () => {
    opened = [...document.querySelectorAll('details.sec-fold:not([open]), details.timeline:not([open]), details.rd-timeline:not([open])')];
    opened.forEach(d => { d.open = true; });
  });
  addEventListener('afterprint', () => { opened.forEach(d => { d.open = false; }); opened = []; });
})();
