/* Navy edition: phone menu, company-list sort and filter, print buttons. Local only. */
(() => {
  const toggle = document.querySelector('.nav-toggle');
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    document.getElementById('site-nav')?.classList.toggle('open', !open);
  });

  document.querySelectorAll('[data-rd-print]').forEach(b => b.addEventListener('click', () => window.print()));

  const table = document.querySelector('[data-co-table]');
  if (!table) return;
  const controls = document.querySelector('[data-co-controls]');
  const search = document.querySelector('[data-co-search]');
  const sort = document.querySelector('[data-co-sort]');
  const filter = document.querySelector('[data-co-filter]');
  const count = document.querySelector('[data-co-count]');
  const empty = document.querySelector('[data-co-empty]');
  const body = table.tBodies[0];
  const rows = [...body.rows];
  const ja = document.documentElement.lang === 'ja';
  controls.hidden = false;   // without JavaScript the full static table stays readable

  const order = {
    'name': (a, b) => a.dataset.i - b.dataset.i,
    'score-desc': (a, b) => b.dataset.score - a.dataset.score || a.dataset.i - b.dataset.i,
    'score-asc': (a, b) => a.dataset.score - b.dataset.score || a.dataset.i - b.dataset.i,
    'date': (a, b) => b.dataset.date.localeCompare(a.dataset.date) || a.dataset.i - b.dataset.i,
  };
  const keep = {
    'all': () => true,
    'full': r => r.dataset.full === 'true',
    'provisional': r => r.dataset.full === 'false',
    'example': r => r.dataset.example === 'true',
  };
  const update = () => {
    const q = search.value.trim().toLocaleLowerCase();
    let shown = 0;
    rows.sort(order[sort.value]).forEach(r => {
      const match = r.dataset.search.includes(q) && keep[filter.value](r);
      r.hidden = !match;
      if (match) shown++;
      body.appendChild(r);
    });
    count.textContent = ja ? `${shown}社を表示` : `${shown} companies shown`;
    empty.hidden = shown !== 0;
  };
  [search, sort, filter].forEach(el => el.addEventListener(el === search ? 'input' : 'change', update));
  update();
})();
