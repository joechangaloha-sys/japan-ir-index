/* Navy edition: phone menu, company-list sort and filter, examples filter, print buttons. Local only. */
(() => {
  const toggle = document.querySelector('.nav-toggle');
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    document.getElementById('site-nav')?.classList.toggle('open', !open);
  });

  document.querySelectorAll('[data-rd-print]').forEach(b => b.addEventListener('click', () => window.print()));

  // Homepage company search: an exact match from the suggestion list opens that company's page;
  // anything else goes to the company list with the text as ?q= (also the no-JavaScript route).
  const homeSearch = document.querySelector('[data-home-search]');
  homeSearch?.addEventListener('submit', ev => {
    const input = homeSearch.querySelector('input[name="q"]');
    const v = input.value.trim().toLocaleLowerCase();
    const opt = [...(input.list?.options || [])].find(o => {
      const val = o.value.toLocaleLowerCase();
      return val === v || (/^[0-9a-z]{4}$/.test(v) && val.includes(`(${v})`)) || val.includes(`（${v}）`);
    });
    if (opt) { ev.preventDefault(); location.href = opt.dataset.href; }
  });

  // Examples to follow: show one area, or the examples whose text matches the filter
  const exTools = document.querySelector('[data-ex-tools]');
  if (exTools) {
    exTools.hidden = false;
    const ja = document.documentElement.lang === 'ja';
    const input = exTools.querySelector('[data-ex-search]');
    const count = exTools.querySelector('[data-ex-count]');
    const buttons = [...exTools.querySelectorAll('[data-ex-filter]')];
    const areas = [...document.querySelectorAll('.rd-ex-area')];
    const chips = [...document.querySelectorAll('.rd-ex-chips li')];
    let area = '';
    const update = () => {
      const q = input.value.trim().toLocaleLowerCase();
      let shown = 0, total = 0;
      areas.forEach(a => {
        let inArea = 0;
        a.querySelectorAll('.rd-ex-q').forEach(item => {
          const ok = (!area || a.dataset.exArea === area) && (!q || item.textContent.toLocaleLowerCase().includes(q));
          item.hidden = !ok;
          total++;
          if (ok) { shown++; inArea++; }
        });
        a.hidden = inArea === 0;
      });
      chips.forEach(c => { c.hidden = !!area && c.dataset.exArea !== area; });
      buttons.forEach(b => b.setAttribute('aria-pressed', String(b.dataset.exFilter === area)));
      count.textContent = shown === total ? '' : shown === 0
        ? (ja ? '該当する参考事例はありません。「すべて」を選ぶか、別の語でお試しください。' : 'No examples match. Choose All, or try another word.')
        : (ja ? `34項目中${shown}項目を表示` : `Showing ${shown} of 34 questions`);
    };
    buttons.forEach(b => b.addEventListener('click', () => { area = b.dataset.exFilter; update(); }));
    input.addEventListener('input', update);
    // a link to one question's examples always shows it, whatever the filter
    window.addEventListener('hashchange', () => {
      if (location.hash.startsWith('#ex-') && location.hash !== '#ex-nav' && document.querySelector(location.hash)?.hidden) {
        area = ''; input.value = ''; update(); document.querySelector(location.hash).scrollIntoView();
      }
    });
  }

  const table = document.querySelector('[data-co-table]');
  if (!table) return;
  const controls = document.querySelector('[data-co-controls]');
  const search = document.querySelector('[data-co-search]');
  const sort = document.querySelector('[data-co-sort]');
  const filter = document.querySelector('[data-co-filter]');
  const sector = document.querySelector('[data-co-sector]');
  const size = document.querySelector('[data-co-size]');
  const range = document.querySelector('[data-co-range]');
  const count = document.querySelector('[data-co-count]');
  const empty = document.querySelector('[data-co-empty]');
  const az = document.querySelector('[data-co-az]');
  const body = table.tBodies[0];
  const rows = [...body.rows];
  const ja = document.documentElement.lang === 'ja';
  controls.hidden = false;   // without JavaScript the full static table stays readable
  const q0 = new URLSearchParams(location.search).get('q');
  if (q0 && search) search.value = q0;   // from the homepage search

  const order = {
    'name': (a, b) => a.dataset.i - b.dataset.i,
    'score-desc': (a, b) => b.dataset.score - a.dataset.score || a.dataset.i - b.dataset.i,
    'score-asc': (a, b) => a.dataset.score - b.dataset.score || a.dataset.i - b.dataset.i,
    'date': (a, b) => b.dataset.date.localeCompare(a.dataset.date) || a.dataset.i - b.dataset.i,
  };
  const keep = {
    'all': () => true,
    'full': r => r.dataset.full === 'true',
    'provisional': r => r.dataset.full === 'false',
    'example': r => r.dataset.example === 'true',
  };
  const update = () => {
    const q = search.value.trim().toLocaleLowerCase();
    let shown = 0;
    rows.sort(order[sort.value]).forEach(r => {
      const match = r.dataset.search.includes(q) && keep[filter.value](r)
        && (!sector || sector.value === 'all' || r.dataset.sector === sector.value)
        && (!size || size.value === 'all' || r.dataset.band === size.value)
        && (!range || range.value === 'all' || (() => { const [lo, hi] = range.value.split('-').map(Number), s = Number(r.dataset.score); return s >= lo && s < hi; })());
      r.hidden = !match;
      if (match) shown++;
      body.appendChild(r);
    });
    if (az) {
      az.hidden = sort.value !== 'name';
      az.querySelectorAll('a').forEach(a => {
        rows.forEach(r => { if (r.id === `co-letter-${a.dataset.letter}`) r.removeAttribute('id'); });
        const first = rows.find(r => !r.hidden && r.dataset.letter === a.dataset.letter);
        a.hidden = !first;
        if (first) first.id = `co-letter-${a.dataset.letter}`;
      });
    }
    count.textContent = ja ? `${shown}社を表示` : `${shown} companies shown`;
    empty.hidden = shown !== 0;
  };
  [search, sort, filter, sector, size, range].filter(Boolean).forEach(el => el.addEventListener(el === search ? 'input' : 'change', update));
  update();
})();
/* Print: open the company page's closed section folds and timelines so the PDF carries all three sections, then restore them. */
(() => {
  let opened = [];
  addEventListener('beforeprint', () => {
    opened = [...document.querySelectorAll('details.sec-fold:not([open]), details.timeline:not([open]), details.rd-timeline:not([open])')];
    opened.forEach(d => { d.open = true; });
  });
  addEventListener('afterprint', () => { opened.forEach(d => { d.open = false; }); opened = []; });
})();
