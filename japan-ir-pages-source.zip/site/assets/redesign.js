/* Navy edition: phone menu, company-list sort and filter, examples filter, print buttons. Local only. */
(() => {
  // Search text as typed on a Japanese keyboard: full-width letters and digits, half-width kana and
  // hiragana for a katakana name all match (１４１４, ＳＵＭＣＯ, ｼｮｰﾎﾞﾝﾄﾞ, しょーぼんど). Spaces and ・ are ignored.
  const norm = s => (s || '').normalize('NFKC').toLocaleLowerCase()
    .replace(/[\u3041-\u3096]/g, ch => String.fromCharCode(ch.charCodeAt(0) + 0x60))
    .replace(/[\s・･]/g, '');
  const toggle = document.querySelector('.nav-toggle');
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    // the label says what a tap does next: Menu when closed, Close when open
    if (!toggle.dataset.open) toggle.dataset.open = toggle.textContent;
    toggle.textContent = open ? toggle.dataset.open : (toggle.dataset.close || toggle.dataset.open);
    document.getElementById('site-nav')?.classList.toggle('open', !open);
  });

  document.querySelectorAll('[data-rd-print]').forEach(b => b.addEventListener('click', () => window.print()));

  // Homepage company search: an exact match from the suggestion list opens that company's page;
  // anything else goes to the company list with the text as ?q= (also the no-JavaScript route).
  const homeSearch = document.querySelector('[data-home-search]');
  homeSearch?.addEventListener('submit', ev => {
    const input = homeSearch.querySelector('input[name="q"]');
    const v = norm(input.value);
    const opt = [...(input.list?.options || [])].find(o => {
      const val = norm(o.value);   // NFKC turns （1414） into (1414)
      return val === v || (/^[0-9a-z]{4}$/.test(v) && val.includes(`(${v})`));
    });
    if (opt) { ev.preventDefault(); location.href = opt.dataset.href; }
  });

  // Articles: show one topic (16 Nov 2026)
  const topics = document.querySelector('[data-topics]');
  if (topics) {
    topics.hidden = false;
    const tb = [...topics.querySelectorAll('[data-topic-filter]')];
    const cards = [...document.querySelectorAll('.cx-card[data-topic]')];
    tb.forEach(b => b.addEventListener('click', () => {
      const k = b.dataset.topicFilter;
      cards.forEach(c => { c.hidden = !!k && c.dataset.topic !== k; });
      tb.forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    }));
  }

  // Examples to follow: show one area, or the examples whose text matches the filter
  const exTools = document.querySelector('[data-ex-tools]');
  if (exTools) {
    exTools.hidden = false;
    const ja = document.documentElement.lang === 'ja';
    const input = exTools.querySelector('[data-ex-search]');
    const count = exTools.querySelector('[data-ex-count]');
    const buttons = [...exTools.querySelectorAll('[data-ex-filter]')];
    const areas = [...document.querySelectorAll('.rd-ex-area')];
    const chips = [...document.querySelectorAll('.rd-ex-chips li')];
    let area = '';
    const update = () => {
      const q = input.value.trim().toLocaleLowerCase();
      let shown = 0, total = 0;
      areas.forEach(a => {
        let inArea = 0;
        a.querySelectorAll('.rd-ex-q').forEach(item => {
          const ok = (!area || a.dataset.exArea === area) && (!q || item.textContent.toLocaleLowerCase().includes(q));
          item.hidden = !ok;
          total++;
          if (ok) { shown++; inArea++; }
        });
        a.hidden = inArea === 0;
      });
      chips.forEach(c => { c.hidden = !!area && c.dataset.exArea !== area; });
      buttons.forEach(b => b.setAttribute('aria-pressed', String(b.dataset.exFilter === area)));
      count.textContent = shown === total ? '' : shown === 0
        ? (ja ? '該当する参考事例はありません。「すべて」を選ぶか、別の語でお試しください。' : 'No examples match. Choose All, or try another word.')
        : (ja ? `34項目中${shown}項目を表示` : `Showing ${shown} of 34 questions`);
    };
    buttons.forEach(b => b.addEventListener('click', () => { area = b.dataset.exFilter; update(); }));
    input.addEventListener('input', update);
    // a link to one question's examples always shows it, whatever the filter
    window.addEventListener('hashchange', () => {
      if (location.hash.startsWith('#ex-') && location.hash !== '#ex-nav' && document.querySelector(location.hash)?.hidden) {
        area = ''; input.value = ''; update(); document.querySelector(location.hash).scrollIntoView();
      }
    });
  }

  const table = document.querySelector('[data-co-table]');
  if (!table) return;
  const controls = document.querySelector('[data-co-controls]');
  const search = document.querySelector('[data-co-search]');
  const sort = document.querySelector('[data-co-sort]');
  const filter = document.querySelector('[data-co-filter]');
  const sector = document.querySelector('[data-co-sector]');
  const size = document.querySelector('[data-co-size]');
  const range = document.querySelector('[data-co-range]');
  const count = document.querySelector('[data-co-count]');
  const empty = document.querySelector('[data-co-empty]');
  const az = document.querySelector('[data-co-az]');
  const body = table.tBodies[0];
  const rows = [...body.rows];
  const ja = document.documentElement.lang === 'ja';
  controls.hidden = false;   // without JavaScript the full static table stays readable
  rows.forEach(r => { r.dataset.norm = norm(r.dataset.search); });
  // The choices live in the address (?q=&sort=&show=&sector=&score=&size=), so Back, reload and a
  // shared link keep them; ?q= also comes from the homepage search. Defaults are left out.
  const params = [['q', search], ['sort', sort], ['show', filter], ['sector', sector], ['score', range], ['size', size]]
    .filter(([, el]) => el);
  const defaults = Object.fromEntries(params.map(([k, el]) => [k, el.value]));
  const url0 = new URLSearchParams(location.search);
  params.forEach(([k, el]) => {
    const v = url0.get(k);
    if (v === null) return;
    if (el.tagName === 'SELECT' && ![...el.options].some(o => o.value === v)) return;
    el.value = v;
  });
  const more = document.querySelector('[data-co-more]');
  const advanced = controls.querySelector('details');
  if (advanced && params.some(([k, el]) => advanced.contains(el) && el.value !== defaults[k])) advanced.open = true;
  const batch = 25;
  let limit = Math.min(rows.length, Math.max(batch, Number(url0.get('limit')) || batch));
  const languageLinks = document.querySelectorAll('.rd-lang a[lang]');
  const directoryChoices = () => {
    const choices = new URLSearchParams();
    params.forEach(([key, el]) => {
      const value = key === 'q' ? el.value.trim() : el.value;
      if (value && value !== defaults[key]) choices.set(key, value);
    });
    if (limit > batch) choices.set('limit', limit);
    return choices;
  };
  const syncLanguageLinks = () => {
    const choices = directoryChoices();
    // English and Japanese use different default sorts. Keep the current order on a filtered list.
    if (choices.size || new URLSearchParams(location.search).get('sort') === sort.value) choices.set('sort', sort.value);
    languageLinks.forEach(link => {
      const target = new URL(link.href);
      target.search = choices.toString();
      link.href = target.href;
    });
  };
  const remember = () => {
    const u = new URLSearchParams(location.search);
    for (const [key] of params) u.delete(key);
    u.delete('limit');
    directoryChoices().forEach((value, key) => u.set(key, value));
    const s = u.toString();
    history.replaceState(null, '', location.pathname + (s ? `?${s}` : '') + location.hash);
  };

  const order = {
    'name': (a, b) => a.dataset.n - b.dataset.n,
    'code': (a, b) => a.dataset.code.localeCompare(b.dataset.code),
    'score-desc': (a, b) => b.dataset.score - a.dataset.score || a.dataset.i - b.dataset.i,
    'score-asc': (a, b) => a.dataset.score - b.dataset.score || a.dataset.i - b.dataset.i,
    'date': (a, b) => b.dataset.date.localeCompare(a.dataset.date) || a.dataset.i - b.dataset.i,
  };
  const keep = {
    'all': () => true,
    'full': r => r.dataset.full === 'true',
    'provisional': r => r.dataset.full === 'false',
    'example': r => r.dataset.example === 'true',
  };
  const update = () => {
    const q = norm(search.value);
    let shown = 0;
    rows.sort(order[sort.value] || order.name).forEach(r => {
      const match = r.dataset.norm.includes(q) && keep[filter.value](r)
        && (!sector || sector.value === 'all' || r.dataset.sector === sector.value)
        && (!size || size.value === 'all' || r.dataset.band === size.value)
        && (!range || range.value === 'all' || (() => { const [lo, hi] = range.value.split('-').map(Number), s = Number(r.dataset.score); return s >= lo && s < hi; })());
      if (match) shown++;
      r.hidden = !match || (more && shown > limit);
      r.dataset.matches = String(match);
      body.appendChild(r);
    });
    if (az) {
      az.hidden = sort.value !== 'name';
      az.querySelectorAll('a').forEach(a => {
        rows.forEach(r => { if (r.id === `co-letter-${a.dataset.letter}`) r.removeAttribute('id'); });
        const first = rows.find(r => r.dataset.matches === 'true' && r.dataset.letter === a.dataset.letter);
        a.hidden = !first;
        if (first) first.id = `co-letter-${a.dataset.letter}`;
      });
    }
    const visible = more ? Math.min(limit, shown) : shown;
    count.textContent = ja ? `${shown}社中${visible}社を表示` : `Showing ${visible} of ${shown} companies`;
    if (more) more.hidden = visible >= shown;
    empty.hidden = shown !== 0;
    syncLanguageLinks();
  };
  [search, sort, filter, sector, size, range].filter(Boolean).forEach(el => el.addEventListener(el === search ? 'input' : 'change', () => { limit = batch; remember(); update(); }));
  more?.addEventListener('click', () => {
    const firstNew = rows.find(r => r.hidden && r.dataset.matches === 'true');
    limit += batch;
    remember(); update();
    firstNew?.querySelector('a')?.focus();
  });
  function revealLetter(hash) {
    const row = document.getElementById(hash.slice(1));
    if (!row || !row.hidden || row.dataset.matches !== 'true') return;
    const index = rows.filter(r => r.dataset.matches === 'true').indexOf(row);
    limit = Math.ceil((index + 1) / batch) * batch;
    remember(); update();
    row.scrollIntoView();
  }
  az?.addEventListener('click', event => {
    const link = event.target.closest('a');
    if (link) revealLetter(link.hash);
  });
  update();
  if (location.hash.startsWith('#co-letter-')) revealLetter(location.hash);
})();
/* Print: open the company page's closed section folds and timelines so the PDF carries all three sections, then restore them. */
(() => {
  let opened = [];
  addEventListener('beforeprint', () => {
    opened = [...document.querySelectorAll('details.sec-fold:not([open]), details.timeline:not([open]), details.rd-timeline:not([open]), details.ap-more:not([open])')];
    opened.forEach(d => { d.open = true; });
  });
  addEventListener('afterprint', () => { opened.forEach(d => { d.open = false; }); opened = []; });
})();
