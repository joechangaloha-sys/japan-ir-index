<?xml version="1.0" encoding="UTF-8"?>
<!-- Renders the site's RSS feeds (/{en,ja}/insights/feed.xml, /{en,ja}/changes/feed.xml) as a readable page when a
     browser opens them; feed readers ignore it. The language comes from the channel's <language>. -->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" encoding="UTF-8" indent="no"/>
  <xsl:variable name="ja" select="/rss/channel/language = 'ja'"/>
  <xsl:template match="/">
    <html>
      <xsl:attribute name="lang"><xsl:value-of select="/rss/channel/language"/></xsl:attribute>
      <head>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <meta name="robots" content="noindex"/>
        <title><xsl:value-of select="/rss/channel/title"/></title>
        <style>
          body{margin:0;background:#f7f7f4;color:#1b2430;font:16px/1.75 "IBM Plex Sans","Hiragino Kaku Gothic ProN","Noto Sans JP",system-ui,sans-serif}
          .bar{background:#0b2545;color:#fff;padding:14px max(16px,env(safe-area-inset-left,0px));font-size:14px}
          .bar a{color:#fff}
          main{max-width:46rem;margin:0 auto;padding:32px max(16px,env(safe-area-inset-left,0px)) 64px}
          h1{font:600 1.9rem/1.3 "Source Serif 4",Georgia,"Hiragino Mincho ProN",serif;margin:0 0 .4em;color:#0b2545}
          .note{background:#fff;border:1px solid #d8dde4;padding:14px 16px;margin:0 0 28px;font-size:15px}
          .note code{background:#eef1f5;padding:2px 6px;word-break:break-all}
          ol{list-style:none;padding:0;margin:0}
          li{border-top:1px solid #d8dde4;padding:18px 0}
          li a{font:600 1.15rem/1.45 "Source Serif 4",Georgia,"Hiragino Mincho ProN",serif;color:#0b2545}
          .date{display:block;color:#5d6876;font-size:14px;margin:4px 0}
          p{margin:0}
        </style>
      </head>
      <body>
        <div class="bar"><a href="{/rss/channel/link}">Japan IR Index</a></div>
        <main>
          <h1><xsl:value-of select="/rss/channel/title"/></h1>
          <p class="note">
            <xsl:choose>
              <xsl:when test="$ja">これはRSSフィードです。フィードリーダーにこのページのアドレスを登録すると、新しい記事が届きます。<br/><code><xsl:value-of select="/rss/channel/link"/>feed.xml</code></xsl:when>
              <xsl:otherwise>This is an RSS feed. Add this page's address to a feed reader to receive new items as they are published.<br/><code><xsl:value-of select="/rss/channel/link"/>feed.xml</code></xsl:otherwise>
            </xsl:choose>
          </p>
          <ol>
            <xsl:for-each select="/rss/channel/item">
              <li>
                <a href="{link}"><xsl:value-of select="title"/></a>
                <span class="date"><xsl:value-of select="substring(pubDate, 6, 11)"/></span>
                <p><xsl:value-of select="description"/></p>
              </li>
            </xsl:for-each>
          </ol>
        </main>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
