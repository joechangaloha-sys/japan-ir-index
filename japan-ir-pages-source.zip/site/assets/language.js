/* Language choice stays in this browser; no visitor data is transmitted. */
(() => {
  const key = 'jir-language';
  const script = document.currentScript;
  if (!script) return;
  const base = new URL('../', script.src);
  const path = location.pathname;

  // Only a neutral homepage negotiates language. Explicit article URLs always win.
  if (path === base.pathname || path === base.pathname + 'index.html') {
    let saved;
    try { saved = localStorage.getItem(key); } catch {}
    const preferred = (navigator.languages || [navigator.language])
      .map(tag => (tag || '').toLowerCase().split('-')[0])
      .find(lang => lang === 'ja' || lang === 'en');
    const lang = ['ja', 'en'].includes(saved) ? saved : preferred || 'en';
    const target = new URL(lang + '/', base);
    target.search = location.search;
    target.hash = location.hash;
    location.replace(target.href);
    return;
  }

  // Store explicit switches only, not ordinary links into the other edition.
  document.addEventListener('click', event => {
    const link = event.target.closest('a');
    if (!link || !link.closest('[aria-label="Language"], [data-language-switch]')) return;
    const target = new URL(link.href, location.href);
    if (target.origin !== base.origin || !target.pathname.startsWith(base.pathname)) return;
    const lang = target.pathname.slice(base.pathname.length).split('/')[0];
    if (lang === 'ja' || lang === 'en') {
      try { localStorage.setItem(key, lang); } catch {}
    }
  });
})();
