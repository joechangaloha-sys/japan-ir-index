/* Language choice stays in this browser; no visitor data is transmitted. */
(() => {
  const key = 'jir-language';
  const script = document.currentScript;
  if (!script) return;
  const base = new URL('../', script.src);
  // Remember a choice visually, but never navigate without a click.
  let saved;
  try { saved = localStorage.getItem(key); } catch {}
  if (saved === 'ja' || saved === 'en') {
    const chosen = document.querySelector('[data-language-choice="' + saved + '"]');
    if (chosen) chosen.setAttribute('data-preferred', 'true');
  }

  // Store explicit switches only, not ordinary links into the other edition.
  document.addEventListener('click', event => {
    const link = event.target.closest('a');
    if (!link || !link.closest('[aria-label="Language"], [data-language-switch]')) return;
    const target = new URL(link.href, location.href);
    if (target.origin !== base.origin || !target.pathname.startsWith(base.pathname)) return;
    const lang = target.pathname.slice(base.pathname.length).split('/')[0];
    if (lang === 'ja' || lang === 'en') {
      try { localStorage.setItem(key, lang); } catch {}
    }
  });
})();
