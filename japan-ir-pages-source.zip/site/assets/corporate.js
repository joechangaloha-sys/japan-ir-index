/* Local interactions only. No visitor information is submitted or retained. */
document.querySelectorAll('[data-company-search]').forEach(input => {
  const table = document.querySelector('[data-company-table]');
  const select = document.querySelector('[data-company-filter]');
  const count = document.querySelector('[data-result-count]');
  const filter = () => {
    let visible = 0;
    const query = input.value.trim().toLocaleLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      const match = row.dataset.search.includes(query) && (!select || select.value !== 'sample' || row.dataset.sample === 'true');
      row.hidden = !match; if (match) visible++;
    });
    document.querySelectorAll('[data-company-letter]').forEach(link => {
      const target = [...table.querySelectorAll('tbody tr')].find(row => !row.hidden && row.dataset.orderName[0].toUpperCase() === link.dataset.companyLetter);
      link.setAttribute('aria-disabled', String(!target));
      link.tabIndex = target ? 0 : -1;
      if (target) {
        if (!target.id) target.id = `company-${target.dataset.companyId}`;
        link.href = `#${target.id}`;
      } else link.removeAttribute('href');
    });
    count.textContent = `${visible} ${document.documentElement.lang === 'ja' ? '社を表示' : 'companies shown'}`;
    document.querySelector('[data-empty]').hidden = visible !== 0;
  };
  input.addEventListener('input', filter); select?.addEventListener('change', filter); filter();
});
document.querySelectorAll('[data-print]').forEach(button => button.addEventListener('click', () => window.print()));
document.querySelectorAll('[data-question-select]').forEach(select => {
  select.addEventListener('change', () => {
    document.querySelectorAll('[data-question-panel]').forEach(panel => {
      panel.hidden = panel.dataset.questionPanel !== select.value;
    });
  });
});
document.querySelectorAll('[data-brief-form]').forEach(form => form.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(form);
  const ja = document.documentElement.lang === 'ja';
  const body = `${ja ? '英文IR・株主コミュニケーション診断 相談メモ' : 'English IR diagnostic — enquiry brief'}\n\n${ja ? '会社名・証券コード' : 'Company / ticker'}: ${data.get('company')}\n${ja ? '比較したい企業' : 'Suggested peers'}: ${data.get('peers')}\n${ja ? 'ご相談内容' : 'Priorities'}: ${data.get('priorities')}\n\n${ja ? 'このメモはブラウザー内で作成されました。送信されていません。' : 'Created locally in your browser. This brief has not been sent.'}\n`;
  const url = URL.createObjectURL(new Blob([body], {type:'text/plain;charset=utf-8'}));
  const link = document.createElement('a'); link.href = url; link.download = 'japan-ir-enquiry.txt'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  const status = form.querySelector('[role=status]'); status.hidden = false;
  status.textContent = ja ? '相談メモをダウンロードしました。情報は送信されていません。' : 'Brief downloaded. No information has been submitted.';
}));
