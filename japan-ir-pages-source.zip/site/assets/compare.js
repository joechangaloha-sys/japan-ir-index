/* Two companies side by side (/en/compare/, /ja/compare/). Data: assets/compare-data.json, written by
   scripts/section_pages.py from the same score files the data page offers. The chosen pair is kept in the
   address (?a=6859&b=6273), so a comparison can be bookmarked or sent to a colleague. */
(function () {
  var form = document.querySelector('[data-compare]');
  var out = document.querySelector('[data-compare-out]');
  if (!form || !out) return;
  var lang = form.dataset.lang === 'ja' ? 'ja' : 'en';
  var T = lang === 'ja'
    ? { total: '英文開示スコア（100点満点）', area: '評価領域', q: '評価項目', diff: '差', reviewed: '確認日', sector: '業種',
        open: '調査結果を見る →', none: '該当する企業が見つかりません。会社名か証券コードで選んでください。', same: '異なる2社を選んでください。',
        pick: '2社を選ぶと、ここに比較を表示します。', unreviewed: '未確認', load: 'データを読み込めませんでした。時間をおいて再度お試しください。',
        qnote: '各項目は5点満点です。差は1社目から2社目を引いた値です。' }
    : { total: 'English disclosure score (of 100)', area: 'Assessment area', q: 'Question', diff: 'Difference', reviewed: 'Reviewed', sector: 'Sector',
        open: 'Full record →', none: 'No company matches. Choose by name or securities code.', same: 'Choose two different companies.',
        pick: 'Choose two companies to see the comparison here.', unreviewed: 'Not searched', load: 'The data could not be loaded. Please try again later.',
        qnote: 'Each question is scored out of 5. The difference is the first company minus the second.' };
  var a = form.elements.a, b = form.elements.b, list = document.getElementById('cmp-list');
  var data = null, byTicker = {}, byLabel = {};

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function label(c) { return c[lang] + ' (' + c.t + ')'; }
  function find(value) {
    var v = value.trim();
    if (!v) return null;
    if (byLabel[v]) return byLabel[v];
    var up = v.toUpperCase();
    if (byTicker[up]) return byTicker[up];
    var low = v.toLowerCase(), hits = data.companies.filter(function (c) {
      return c.en.toLowerCase().indexOf(low) === 0 || c.ja.indexOf(v) === 0;
    });
    if (hits.length !== 1) hits = data.companies.filter(function (c) { return c.en.toLowerCase().indexOf(low) > -1 || c.ja.indexOf(v) > -1; });
    return hits.length === 1 ? hits[0] : null;
  }
  function message(text) { out.innerHTML = '<p class="muted">' + esc(text) + '</p>'; }
  function cell(x, y, digits) {
    var fx = parseFloat(x), fy = parseFloat(y);
    var cls = isNaN(fx) || isNaN(fy) || fx === fy ? '' : (fx > fy ? ' sp-hi' : '');
    return '<td class="num' + cls + '">' + esc(x) + '</td>';
  }
  function diff(x, y, digits) {
    var fx = parseFloat(x), fy = parseFloat(y);
    if (isNaN(fx) || isNaN(fy)) return '<td class="num muted">–</td>';
    var d = fx - fy, s = (d > 0 ? '+' : d < 0 ? '−' : '') + Math.abs(d).toFixed(digits);
    return '<td class="num' + (d === 0 ? ' muted' : '') + '">' + s + '</td>';
  }
  function row(head, x, y, digits, th) {
    return '<tr>' + (th || '') + '<th scope="row">' + head + '</th>' + cell(x, y) + cell(y, x) + diff(x, y, digits) + '</tr>';
  }
  function render() {
    var ca = find(a.value), cb = find(b.value);
    var params = new URLSearchParams();
    if (ca) params.set('a', ca.t);
    if (cb) params.set('b', cb.t);
    var qs = params.toString();
    history.replaceState(null, '', location.pathname + (qs ? '?' + qs : ''));
    if (!a.value.trim() || !b.value.trim()) return message(T.pick);
    if (!ca || !cb) return message(T.none);
    if (ca.t === cb.t) return message(T.same);
    var base = '/' + lang + '/';
    var prefix = form.dataset.src.replace('assets/compare-data.json', '');   // back to the site root
    function link(c) { return '<a href="' + prefix + lang + '/companies/' + c.t + '/">' + esc(c[lang]) + '</a>'; }
    var head = '<thead><tr><th scope="col">&nbsp;</th><th scope="col" class="num">' + link(ca) + '</th><th scope="col" class="num">' + link(cb) +
               '</th><th scope="col" class="num">' + T.diff + '</th></tr></thead>';
    var top = row(T.total, ca.total, cb.total, 1) +
      '<tr><th scope="row">' + T.sector + '</th><td class="num">' + esc(ca.sector[lang]) + '</td><td class="num">' + esc(cb.sector[lang]) + '</td><td></td></tr>' +
      '<tr><th scope="row">' + T.reviewed + '</th><td class="num">' + esc(ca.date) + '</td><td class="num">' + esc(cb.date) + '</td><td></td></tr>';
    var areas = data.areas[lang].map(function (name, i) { return row(esc(name), ca.areas[i], cb.areas[i], 1); }).join('');
    var qhead = '<thead><tr><th scope="col">&nbsp;</th><th scope="col">' + T.q + '</th><th scope="col" class="num">' + esc(ca[lang]) +
                '</th><th scope="col" class="num">' + esc(cb[lang]) + '</th><th scope="col" class="num">' + T.diff + '</th></tr></thead>';
    var qs2 = data.codes.map(function (code, i) {
      var x = ca.q.charAt(i), y = cb.q.charAt(i);
      x = x === '-' ? T.unreviewed : x; y = y === '-' ? T.unreviewed : y;
      var name = (data.questions[lang] || {})[code] || code;
      var q = '<a href="' + prefix + lang + '/questions/' + code.toLowerCase() + '/">' + esc(name) + '</a>';
      return row(q, x, y, 0, '<td class="num code">' + code + '</td>');
    }).join('');
    out.innerHTML =
      '<div class="cx-table-wrap"><table class="rd-table sp-cmp">' + head + '<tbody>' + top + '</tbody></table></div>' +
      '<h2>' + T.area + '</h2><div class="cx-table-wrap"><table class="rd-table sp-cmp">' + head + '<tbody>' + areas + '</tbody></table></div>' +
      '<h2>' + T.q + '</h2><p class="muted">' + T.qnote + '</p><div class="cx-table-wrap"><table class="rd-table sp-cmp sp-cmp-q">' + qhead + '<tbody>' + qs2 + '</tbody></table></div>';
  }

  fetch(form.dataset.src).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }).then(function (json) {
    data = json;
    var options = '';
    data.companies.forEach(function (c) {
      byTicker[c.t.toUpperCase()] = c;
      byLabel[label(c)] = c;
      options += '<option value="' + esc(label(c)) + '">';
    });
    list.innerHTML = options;
    var params = new URLSearchParams(location.search);
    ['a', 'b'].forEach(function (k) {
      var c = byTicker[(params.get(k) || '').toUpperCase()];
      if (c) form.elements[k].value = label(c);
    });
    a.addEventListener('change', render); b.addEventListener('change', render);
    a.addEventListener('input', function () { if (byLabel[a.value]) render(); });
    b.addEventListener('input', function () { if (byLabel[b.value]) render(); });
    render();
  }).catch(function () { message(T.load); });
})();
