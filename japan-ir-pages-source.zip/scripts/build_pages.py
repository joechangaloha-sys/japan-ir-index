"""Pages deploy step: copy site/ to _site/ and make internal links work where the site is served.

Packaged as scripts/build_pages.py by package_pages.py; the Pages workflow runs it. With site/CNAME
(a custom domain, site_config.CUSTOM_DOMAIN) the site is at the domain root and links stay as built
("/en/..."). Without it the site is served under the repository's sub-path on github.io, and
"/..." becomes "/<repo>/...".
"""
import os,re,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
repo=os.environ.get('GITHUB_REPOSITORY','joechangaloha-sys/project-revival').split('/')[-1]
custom=(root/'site'/'CNAME').exists()
base='' if custom or repo.lower().endswith('.github.io') else '/'+repo
out=root/'_site'
if out.exists():shutil.rmtree(out)
shutil.copytree(root/'site',out)
for p in out.rglob('*.html'):
 s=p.read_text(encoding='utf-8')
 s=re.sub(r'((?:href|src|action)=[\"\'])/(?!/)',lambda m:m[1]+base+'/',s)
 s=re.sub(r'(content=[\"\'][^\"\']*?url=)/(?!/)',lambda m:m[1]+base+'/',s,flags=re.I)
 p.write_text(s,encoding='utf-8')
(out/'.nojekyll').touch()
print(f'Built {len(list(out.rglob("*.html")))} pages for {base or "/"}'+(' (custom domain)' if custom else ''))
