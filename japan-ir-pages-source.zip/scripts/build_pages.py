"""Build a static Pages artifact with repository-relative internal links."""
import os,re,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
repo=os.environ.get('GITHUB_REPOSITORY','joechangaloha-sys/project-revival').split('/')[-1]
base='' if repo.lower().endswith('.github.io') else '/'+repo
out=root/'_site'
if out.exists():shutil.rmtree(out)
shutil.copytree(root/'site',out)
for p in out.rglob('*.html'):
 s=p.read_text(encoding='utf-8')
 s=re.sub(r'((?:href|src|action)=[\"\'])/(?!/)',lambda m:m[1]+base+'/',s)
 s=re.sub(r'(content=[\"\'][^\"\']*?url=)/(?!/)',lambda m:m[1]+base+'/',s,flags=re.I)
 p.write_text(s,encoding='utf-8')
(out/'.nojekyll').touch()
print(f'Built {len(list(out.rglob("*.html")))} pages for {base or "/"}')
